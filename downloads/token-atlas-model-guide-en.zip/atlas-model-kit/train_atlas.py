#!/usr/bin/env python3
"""Train a compatible Token Atlas v1 model from a JSON list of [question, answer]."""
import argparse, json, random, time, unicodedata
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
D,H,L,T=48,4,2,48
SPECIAL=['<pad>','<bos>','<eos>','<unk>','<q>','<a>']

def tok(text):
    # Same groups as the browser: Unicode letters/numbers/underscore; punctuation separately.
    result=[]; word=''
    for c in text.lower():
        if c=='_' or unicodedata.category(c)[0] in ('L','N'):word+=c
        else:
            if word:result.append(word);word=''
            if not c.isspace():result.append(c)
    if word:result.append(word)
    return result

def prepare(filename,language):
    raw=json.loads(Path(filename).read_text(encoding='utf-8'))
    if not isinstance(raw,list) or not raw:raise ValueError('Data musí být neprázdný JSON seznam dvojic [otázka, odpověď].')
    pairs=[]
    for i,row in enumerate(raw,1):
        if not isinstance(row,list) or len(row)!=2 or not all(isinstance(v,str) and v.strip() for v in row):raise ValueError(f'Položka {i}: očekávám dva neprázdné texty.')
        q,a=[v.strip() for v in row]
        if len(q)>250:raise ValueError(f'Položka {i}: otázka může mít nejvýše 250 znaků.')
        if len(tok(q))+len(tok(a))+4>T:raise ValueError(f'Položka {i}: otázka a odpověď mají dohromady více než 44 tokenů. Zkrať texty.')
        if any(len(v)>80 for v in tok(q+' '+a)):raise ValueError(f'Položka {i}: příliš dlouhý token (maximum 80 znaků).')
        pairs.append((q,a))
    original_count=len(pairs)
    prefix='opiš číslo' if language=='cs' else 'copy number'
    noun='číslo' if language=='cs' else 'number'
    # Actual copying examples fill a fixed-size vocabulary, not dummy tokens.
    words=set(t for q,a in pairs for t in tok(q+' '+a))
    if len(words)<994:
        pairs.append((f'{prefix} 0 .',f'{noun} 0 .'))
        words.update(tok(prefix+' '+noun+' 0 .'))
    if len(words)>994:raise ValueError(f'Slovník má {len(words)} běžných tokenů, povoleno je nejvýše 994 (včetně případných doplňovacích příkladů). Omez téma nebo slovní zásobu.')
    vocab=SPECIAL+sorted(words)
    i=0
    while len(vocab)<1000:
        word=str(i)
        if word not in vocab:
            pairs.append((f'{prefix} {i} .',f'{noun} {i} .'));vocab.append(word)
        i+=1
    lookup={v:i for i,v in enumerate(vocab)}
    seq=[[1,4]+[lookup[t] for t in tok(q)]+[5]+[lookup[t] for t in tok(a)]+[2] for q,a in pairs]
    X=torch.zeros((len(seq),T),dtype=torch.long);Y=torch.full_like(X,-100)
    for i,s in enumerate(seq):
        X[i,:len(s)-1]=torch.tensor(s[:-1]);start=s.index(5)
        Y[i,start:len(s)-1]=torch.tensor(s[start+1:])
    return pairs,seq,vocab,lookup,X,Y,original_count

class Block(nn.Module):
 def __init__(self):
  super().__init__();self.n1=nn.LayerNorm(D);self.qkv=nn.Linear(D,3*D);self.proj=nn.Linear(D,D);self.n2=nn.LayerNorm(D);self.fc=nn.Linear(D,2*D);self.out=nn.Linear(2*D,D)
 def forward(self,x):
  b,t,d=x.shape;q,k,v=self.qkv(self.n1(x)).chunk(3,-1)
  q,k,v=[z.reshape(b,t,H,D//H).transpose(1,2) for z in (q,k,v)]
  a=F.scaled_dot_product_attention(q,k,v,is_causal=True)
  x=x+self.proj(a.transpose(1,2).reshape(b,t,d));return x+self.out(F.gelu(self.fc(self.n2(x)),approximate='tanh'))
class Model(nn.Module):
 def __init__(self):
  super().__init__();self.emb=nn.Embedding(1000,D);self.pos=nn.Embedding(T,D);self.blocks=nn.ModuleList([Block() for _ in range(L)]);self.norm=nn.LayerNorm(D);self.head=nn.Linear(D,1000)
 def forward(self,x):
  z=self.emb(x)+self.pos(torch.arange(x.shape[1]));
  for b in self.blocks:z=b(z)
  return self.head(self.norm(z))

def main():
    parser=argparse.ArgumentParser(description='Natrénuje Token Atlas v1 z vlastních dvojic otázka–odpověď.')
    parser.add_argument('--data',default='data.json');parser.add_argument('--out',default='muj-model')
    parser.add_argument('--steps',type=int,default=1600);parser.add_argument('--threads',type=int,default=4)
    parser.add_argument('--seed',type=int,default=42);parser.add_argument('--fill-language',choices=['cs','en'],default='cs')
    parser.add_argument('--check',action='store_true',help='Pouze zkontroluje data, netrénuje.')
    args=parser.parse_args()
    if args.steps<1 or args.threads<1:parser.error('--steps a --threads musejí být kladná čísla.')
    torch.set_num_threads(args.threads);torch.manual_seed(args.seed);random.seed(args.seed);np.random.seed(args.seed)
    try:pairs,seq,vocab,lookup,X,Y,original_count=prepare(args.data,args.fill_language)
    except (ValueError,OSError) as e:parser.exit(2,str(e)+'\n')
    print(f'Vlastní příklady: {original_count}, doplňovací: {len(pairs)-original_count}, slovník: {len(vocab)}, kontext: {T}',flush=True)
    if args.check:return
    outdir=Path(args.out)
    if outdir.exists() and any(outdir.iterdir()):parser.exit(2,'Výstupní složka není prázdná. Použij jiné --out; soubory nepřepisuji.\n')
    outdir.mkdir(parents=True,exist_ok=True)
    m=Model();opt=torch.optim.AdamW(m.parameters(),lr=.003,weight_decay=.01)
    losses=[];start=time.time()
    for step in range(args.steps):
        idx=torch.randint(len(X),(48,));logits=m(X[idx]);loss=F.cross_entropy(logits.reshape(-1,1000),Y[idx].reshape(-1))
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1);opt.step()
        if not torch.isfinite(loss):raise RuntimeError('Trénink skončil nečíselnou ztrátou.')
        if step%200==0 or step==args.steps-1:
            losses.append([step+1,loss.item()]);print(f'{step+1}/{args.steps}: loss={loss.item():.5f}, {time.time()-start:.1f} s',flush=True)
        if step==int(args.steps*.625):
            for group in opt.param_groups:group['lr']=.001
    m.eval();weights={k:v.detach().cpu().numpy() for k,v in m.state_dict().items()}
    emb=weights['emb.weight'];center=emb-emb.mean(0);_,sv,vt=np.linalg.svd(center,full_matrices=False)
    coords=center@vt[:3].T;coords=coords/max(float(np.max(np.linalg.norm(coords,axis=1))),1e-9)*3
    flat=[];offsets={}
    for k,v in weights.items():offsets[k]={'offset':len(flat),'shape':list(v.shape)};flat.extend(v.flatten().tolist())
    assert len(flat)==137320
    np.array(flat,dtype='<f4').tofile(outdir/'weights.bin')
    counts=[0]*1000
    for s in seq:
        for t in s:counts[t]+=1
    prompts=[];seen_answers=set()
    for q,a in pairs[:original_count]:
        if a not in seen_answers:prompts.append(q);seen_answers.add(a)
        if len(prompts)==6:break
    meta={'vocab':vocab,'d':D,'heads':H,'layers':L,'context':T,'offsets':offsets,'coords':coords.round(6).tolist(),'counts':counts,'parameters':len(flat),'examples':len(pairs),'steps':args.steps,'loss':losses,'seed':args.seed,'projectionVariance':float(sum(sv[:3]**2)/sum(sv**2)),'examplesPrompt':prompts,'ownExamples':original_count,'fillerExamples':len(pairs)-original_count}
    (outdir/'model.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    (outdir/'corpus.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2),encoding='utf-8')
    previews=[]
    for prompt in prompts:
        ids=[1,4]+[lookup.get(t,3) for t in tok(prompt)]+[5];answer=[]
        for _ in range(40):
            with torch.no_grad():z=m(torch.tensor([ids[-T:]]))[0,-1]
            z[[0,1,3,4,5]]=-1e9;n=int(z.argmax())
            if n==2:break
            ids.append(n);answer.append(vocab[n])
        text=' '.join(answer);previews.append({'question':prompt,'answer':text});print(prompt,'=>',text,flush=True)
    with torch.no_grad():
        ids=[1,4]+[lookup.get(t,3) for t in tok(prompts[0])]+[5]
        reference={'ids':ids,'logits':m(torch.tensor([ids]))[0,-1].tolist()}
    (outdir/'reference.json').write_text(json.dumps(reference),encoding='utf-8')
    report={'torch':torch.__version__,'numpy':np.__version__,'device':'cpu','seconds':round(time.time()-start,2),'ownExamples':original_count,'fillerExamples':len(pairs)-original_count,'trainingLossLastBatch':losses[-1][1],'note':'Training examples only; not an independent generalization evaluation.','previews':previews}
    (outdir/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Hotovo: vyber současně {outdir}/model.json a {outdir}/weights.bin v Token Atlasu. Ostatní soubory neimportuj.')

if __name__=='__main__':main()
