# Create your own model for Token Atlas

This kit includes `train_atlas.py` and an editable `data.json` sample. The script trains a new model from random weights and exports files compatible with Token Atlas. It does not convert GGUF models or fine-tune ChatGPT.

**Training runs in Python on your computer. The exported model runs in your browser.** This small experiment uses the CPU; NVIDIA hardware and CUDA are not required.

## 1. Prepare your environment and question–answer examples

Extract the ZIP and open a terminal in the `atlas-model-kit` folder. These commands are for Debian, Ubuntu and Linux Mint. Skip the first command if Python, venv and pip are already installed.

```bash
sudo apt install python3 python3-venv python3-pip
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "numpy>=1.26,<3"
python -m pip install "torch>=2.2,<3" --index-url https://download.pytorch.org/whl/cpu
mcedit data.json
```

Use Python 3.10 or later with an available PyTorch package. On other platforms, select the appropriate installation command on the [official PyTorch website](https://pytorch.org/get-started/locally/). `requirements.txt` lists the dependencies; the commands above specifically install the CPU build of PyTorch. You can use another text editor if mcedit is not installed.

`data.json` is a UTF-8 JSON array of pairs. The first string is a question, and the second is its desired answer:

```json
[
  ["What is an anchor?", "An anchor helps keep a boat in one place."],
  ["What does an anchor do?", "An anchor helps keep a boat in one place."],
  ["What is a sailboat?", "A sailboat uses wind to move across water."]
]
```

Replace the sample with your own data. The English kit provides 120 examples covering 20 simple topics. Use double quotation marks, no comments, and no comma after the last item.

**Choose a narrow topic and short answers.** Include several genuinely different question phrasings for the same meaning. Avoid contradictory answers. One hundred to a few hundred short pairs are a reasonable starting point for an experiment, not a quality guarantee. Long articles or an entire website do not fit this architecture.

**Current import limits:**

| Property | Fixed value |
|---|---:|
| Vocabulary, including control tokens | 1,000 tokens |
| Embedding dimensions | 48 |
| Transformer layers | 2 |
| Attention heads per layer | 4 |
| Context length | 48 tokens |
| Parameters | 137,320 |
| Weights file size | 549,280 bytes |

The tokenizer lowercases text and splits it into words, numbers and individual punctuation marks. For example, “What is an anchor?” contains five ordinary tokens. This is not the BPE tokenizer used by many large LLMs. A question and its answer together may contain **at most 44 ordinary tokens**; four control tokens occupy the rest of the context. Questions also have a 250-character limit.

The script checks sequence length and vocabulary size. If there are fewer than 994 ordinary tokens, it adds **actual number-copying training examples** to fill the fixed 1,000-token vocabulary. This does not add knowledge of your topic. The counts of your examples and filler examples appear in the console and report. Words introduced by the filler examples also count towards the limit. If the vocabulary exceeds the limit, training stops; words are not silently removed.

Validate your data without training:

```bash
python train_atlas.py --data data.json --fill-language en --check
```

## 2. Train the model and import it into the app

With the `.venv` environment still active, run:

```bash
python train_atlas.py --data data.json --out my-model --steps 1600 --fill-language en
```

Training uses AdamW, backpropagation and next-token prediction on answers. The model sees the question and the preceding part of the answer and learns to continue it. Its weights really change. The printed `loss` measures error on a training batch; a lower value alone does not establish that the model handles unseen questions well.

The output directory contains:

| File | Purpose |
|---|---|
| `model.json` | Vocabulary, architecture, weight layout, PCA coordinates and statistics |
| `weights.bin` | Learned float32 weights |
| `corpus.json` | Training data, including filler examples |
| `report.json` | Library versions, training duration, loss and example answers |
| `reference.json` | Reference logits for one inference calculation, for technical verification |

In Token Atlas, click **Load your own model** and select **only `model.json` and `weights.bin` together, from the same output directory**. Use Ctrl (Command on macOS) to select both files. The app validates compatibility, switches models and displays the new vectors. Do not select the corpus or report for import.

The imported model stays in browser memory until the page reloads; it is not sent to a server. Keep the files. To give it a clearer name in the model selector, rename `model.json` to something such as `sailing.json` before importing.

First, try an exact training question at **temperature 0**. Then try different phrasings and questions absent from the training data. Compare reproduction of learned answers with generalization. Unknown words become `<unk>` and can significantly degrade the result. A high token probability does not guarantee a true answer.

To fix your data, edit it and train into a new directory:

```bash
mcedit data.json
python train_atlas.py --data data.json --out my-model-v2 --steps 2400 --fill-language en
```

The script refuses to overwrite a nonempty output directory. Every run starts from scratch; increasing `--steps` does not resume an earlier run and may not improve answers to new questions.

`--fill-language en` changes only the number-copying filler examples. The script defaults to Czech filler examples, so include this option for the English workflow. Your main dataset determines the language and content of the main answers. Changing the Token Atlas interface language does not translate a model. The same trainer is included in both language kits; its console messages are in Czech.

**What you get:** a real but very small language model for exploring transformer principles. It is not a general chatbot, search engine or reliable knowledge database. Changing the number of layers, dimensions or vocabulary entries also requires changes to the app's inference engine and importer.

The trainer was checked with a full 1,600-step run on the Czech sample, validation by the app's actual importer and a comparison between PyTorch and JavaScript logits (maximum absolute difference below 0.000005). Six checked training questions produced their expected answers. This is not an independent generalization evaluation or a guarantee for a new dataset.
