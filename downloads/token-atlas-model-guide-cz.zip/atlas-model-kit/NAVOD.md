# Vlastní model pro Token Atlas

Tento balíček obsahuje funkční trénovací skript `train_atlas.py` a upravitelný vzor `data.json`. Skript natrénuje nový model od náhodných vah a vyexportuje soubory, které přijímá současný Token Atlas. Není to převod GGUF modelu ani dotrénování ChatGPT.

**Trénování probíhá v Pythonu na tvém počítači. Hotový model potom běží v prohlížeči.** Pro tento malý experiment není nutná NVIDIA ani CUDA; uvedený postup používá CPU.

## 1. Připrav prostředí a vlastní otázky s odpověďmi

Rozbal ZIP a otevři terminál ve složce `atlas-model-kit`. Příkazy níže jsou pro Debian, Ubuntu a Linux Mint. Pokud už máš Python, venv a pip, první příkaz vynech.

```bash
sudo apt install python3 python3-venv python3-pip
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install numpy
python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
mcedit data.json
```

Použij Python 3.10 nebo novější, pro který je dostupný balíček PyTorch. Na jiné platformě vyber odpovídající instalační příkaz na [oficiální stránce PyTorch](https://pytorch.org/get-started/locally/). Soubor `requirements.txt` zachycuje požadované závislosti; příkazy výše záměrně instalují CPU variantu PyTorch.

`data.json` je UTF-8 JSON seznam dvojic. První text je otázka, druhý požadovaná odpověď:

```json
[
  ["Co je kotva?", "Kotva pomáhá udržet loď na jednom místě."],
  ["K čemu slouží kotva?", "Kotva pomáhá udržet loď na jednom místě."],
  ["Co je plachetnice?", "Plachetnice využívá vítr k pohybu po vodě."]
]
```

Můžeš nahradit celý obsah souboru vlastními daty. Přiložený vzor má 120 příkladů pro 20 jednoduchých témat. JSON používá dvojité uvozovky; za poslední položkou není čárka. Žádné komentáře dovnitř JSON nepřidávej.

**Jaká data dávají smysl:** zvol úzké téma a krátké odpovědi. Pro stejný význam přidej několik skutečně různých formulací otázek. Vyhni se protichůdným odpovědím. Sto až několik set krátkých dvojic je rozumný začátek pro experiment, nikoli záruka kvality. Dlouhé články a celý web se do této architektury nehodí.

**Limity současného importu:**

| Vlastnost | Pevná hodnota |
|---|---:|
| Slovník včetně řídicích tokenů | 1 000 tokenů |
| Embedding | 48 rozměrů |
| Transformerové vrstvy | 2 |
| Hlavy attention v každé vrstvě | 4 |
| Kontext | 48 tokenů |
| Počet parametrů | 137 320 |
| Soubor vah | 549 280 bajtů |

Tokenizer dělí text na slova, čísla a jednotlivou interpunkci a převádí jej na malá písmena. V tomto modelu například „Co je kotva?“ tvoří čtyři běžné tokeny. Nejde o BPE tokenizer velkých LLM. Otázka a odpověď dohromady smějí mít nejvýše **44 běžných tokenů**; zbytek kontextu zabírají čtyři řídicí tokeny. Samotná otázka má navíc limit 250 znaků.

Skript zkontroluje délku i velikost slovníku. Máš-li méně než 994 běžných tokenů, doplní **skutečné trénovací příklady opisování čísel**, aby se slovník vešel do pevné architektury s přesně 1 000 položkami. Neznamená to další znalosti tvého tématu. Počet vlastních a doplňovacích příkladů uvidíš při spuštění i v reportu. Do limitu se počítají také slova těchto doplňovacích příkladů. Při překročení limitu se skript zastaví, žádná slova potichu neodstraní.

Kontrola bez trénování:

```bash
python train_atlas.py --data data.json --check
```

## 2. Natrénuj model a otevři ho v aplikaci

Se stále aktivním prostředím `.venv` spusť:

```bash
python train_atlas.py --data data.json --out muj-model --steps 1600
```

Používá se AdamW, zpětné šíření chyby a predikce dalšího tokenu v odpovědi. Model vidí otázku i dosavadní část odpovědi a učí se pokračování. Váhy se skutečně mění. Vypsaná `loss` je chyba na trénovací dávce — pokles sám o sobě neprokazuje, že model rozumí novým otázkám.

Výstupní složka obsahuje:

| Soubor | Význam |
|---|---|
| `model.json` | Slovník, architektura, rozložení vah, PCA souřadnice a statistiky |
| `weights.bin` | Naučené váhy ve float32 |
| `corpus.json` | Použitá data včetně doplňovacích příkladů |
| `report.json` | Verze knihoven, délka tréninku, loss a ukázkové odpovědi |
| `reference.json` | Referenční skóre jednoho výpočtu pro technickou kontrolu |

V Token Atlasu klikni na **„Nahrát vlastní model“** a vyber **současně pouze `model.json` a `weights.bin` ze stejné výstupní složky**. V dialogu použij Ctrl pro výběr obou souborů. Aplikace zkontroluje kompatibilitu, přepne model a zobrazí jeho vektory. Corpus ani report do importu nepatří.

Nahraný model zůstává v paměti prohlížeče do obnovení stránky; na server se neposílá. Soubory si proto uschovej. Pro srozumitelnější název v přepínači můžeš `model.json` před importem přejmenovat například na `plachetnice.json`.

Nejdřív zkus přesnou trénovací otázku s **teplotou 0**. Pak vyzkoušej jiné formulace a odlišné otázky, které v datech nebyly. Sleduj rozdíl mezi reprodukcí známé odpovědi a skutečnou generalizací. Neznámá slova se změní na `<unk>` a mohou výsledek zásadně zhoršit. Vysoká pravděpodobnost tokenu nezaručuje pravdivou odpověď.

Když potřebuješ opravit data, otevři je znovu v `mcedit`, oprav je a trénink spusť do nové složky. Například:

```bash
mcedit data.json
python train_atlas.py --data data.json --out muj-model-v2 --steps 2400
```

Skript záměrně nepřepisuje neprázdnou výstupní složku. Každé spuštění trénuje od začátku; větší `--steps` není pokračování předchozího běhu a nemusí zlepšit odpovědi na nové otázky.

Pro anglická data použij například `--fill-language en`; změní se jazyk doplňovacích příkladů opisování čísel. Obsah a jazyk hlavních odpovědí určují tvoje data. Jazyk rozhraní Token Atlasu model nepřekládá.

**Co tím získáš:** vlastní skutečný, ale velmi malý jazykový model pro pozorování principů transformeru. Není to obecný chatbot, vyhledávač ani spolehlivá znalostní databáze. Změna počtu vrstev, dimenzí nebo slovníku by vyžadovala i úpravy inferenčního enginu a importu v samotné aplikaci.

Ověření přiloženého skriptu: úplný běh 1 600 kroků nad vzorovými daty, úspěšná kontrola stejným validátorem jako v aplikaci a porovnání výsledných skóre PyTorch s JavaScriptovým enginem (maximální absolutní odchylka pod 0,000005). Šest kontrolovaných trénovacích otázek mělo očekávané odpovědi; nejde o test nezávislé generalizace.
